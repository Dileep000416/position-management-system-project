from django.contrib import admin
from django.urls import path, include
from django.views.generic import TemplateView
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView

urlpatterns = [
    path('admin/', admin.site.urls),

    # Backend main dashboard page
    path("", TemplateView.as_view(template_name="frontend/index.html"), name="home"),

    # Backend Positions UI Page
    path("positions/", TemplateView.as_view(template_name="frontend/positions.html"), name="positions-ui"),

    # Backend Open Position UI Page  ✅ FIXED!
    path("positions/open/", TemplateView.as_view(template_name="frontend/open_position.html"), name="open-position-ui"),

    # JWT Auth Endpoints
    path("api/token/", TokenObtainPairView.as_view(), name="token_obtain_pair"),
    path("api/token/refresh/", TokenRefreshView.as_view(), name="token_refresh"),

    # REST API Endpoints
    path("api/positions/", include("positions.urls")),
]
