from rest_framework import serializers
from .models import Position, PositionEvent, UserAccount

# ------------------------------
# USER ACCOUNT SERIALIZER
# ------------------------------
class UserAccountSerializer(serializers.ModelSerializer):
    user = serializers.CharField(source="user.username", read_only=True)

    class Meta:
        model = UserAccount
        fields = ["id", "user", "total_collateral", "locked_collateral", "total_pnl"]


# ------------------------------
# POSITION EVENT SERIALIZER
# ------------------------------
class PositionEventSerializer(serializers.ModelSerializer):
    class Meta:
        model = PositionEvent
        fields = "__all__"
        read_only_fields = ["id", "created_at"]


# ------------------------------
# POSITION SERIALIZER
# ------------------------------
class PositionSerializer(serializers.ModelSerializer):
    owner = serializers.CharField(source="owner.user.username", read_only=True)

    # Computed fields — live values
    liquidation_threshold = serializers.SerializerMethodField()
    leverage_used = serializers.SerializerMethodField()

    class Meta:
        model = Position
        fields = [
            "id",
            "owner",
            "symbol",
            "side",
            "size",
            "entry_price",
            "margin",
            "leverage",
            "unrealized_pnl",
            "realized_pnl",
            "funding_accrued",
            "last_mark_price",
            "liquidation_price",
            "liquidation_threshold",  # computed
            "maintenance_margin_ratio",
            "state",
            "created_at",
            "updated_at",
            "leverage_used",
        ]

        read_only_fields = [
            "id",
            "unrealized_pnl",
            "realized_pnl",
            "funding_accrued",
            "last_mark_price",
            "liquidation_price",
            "owner",
            "created_at",
            "updated_at"
        ]

    # ------------------------------
    # COMPUTED FIELDS
    # ------------------------------
    def get_liquidation_threshold(self, obj):
        """Return price at which the position faces liquidation"""
        if obj.size and obj.margin and obj.leverage:
            return float(obj.entry_price) / obj.leverage
        return None

    def get_leverage_used(self, obj):
        """Return actual leverage used vs collateral"""
        try:
            return float(obj.size) / float(obj.margin)
        except:
            return None
