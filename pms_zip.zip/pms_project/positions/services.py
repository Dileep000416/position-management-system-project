from decimal import Decimal
from .models import Position, PositionEvent, PnLSnapshot


# 🚀 Update Unrealized PnL based on live mark price
def update_unrealized_pnl(position: Position, mark_price: Decimal):
    if mark_price <= 0:
        return position

    entry = Decimal(position.entry_price)
    size = Decimal(position.size)

    pnl = (mark_price - entry) * size if position.side == Position.LONG else (entry - mark_price) * size
    position.unrealized_pnl = pnl
    position.last_mark_price = mark_price
    position.save(update_fields=["unrealized_pnl", "last_mark_price"])

    # Log snapshot
    PnLSnapshot.objects.create(
        position=position,
        mark_price=mark_price,
        unrealized_pnl=pnl
    )

    return position


# 🧮 Calculate liquidation threshold and trigger liquidation
def check_liquidation(position: Position):
    mark = Decimal(position.last_mark_price)
    margin = Decimal(position.margin)
    threshold = Decimal(position.liquidation_threshold)

    if mark <= 0:
        return None

    if (position.side == Position.LONG and mark <= threshold) or \
       (position.side == Position.SHORT and mark >= threshold):

        position.state = Position.STATE_LIQUIDATING
        position.realized_pnl = position.unrealized_pnl
        position.unrealized_pnl = Decimal("0")
        position.save()

        PositionEvent.objects.create(
            position=position,
            event_type=PositionEvent.EVENT_LIQUIDATE,
            size=position.size,
            entry_price=position.entry_price,
            margin=position.margin,
            mark_price=mark,
            realized_pnl=position.realized_pnl,
            unrealized_pnl=0
        )

        return position

    return None


# 🏁 Close Position
def close_position(position: Position, mark_price: Decimal):
    position.state = Position.STATE_CLOSED
    position.realized_pnl = position.unrealized_pnl
    position.unrealized_pnl = Decimal("0")
    position.last_mark_price = mark_price
    position.save()

    PositionEvent.objects.create(
        position=position,
        event_type=PositionEvent.EVENT_CLOSE,
        size=position.size,
        entry_price=position.entry_price,
        margin=position.margin,
        mark_price=mark_price,
        realized_pnl=position.realized_pnl,
        unrealized_pnl=0,
    )

    return position
