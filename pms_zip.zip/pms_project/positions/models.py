from django.db import models
from django.contrib.auth import get_user_model

User = get_user_model()


# ------------------------------
# USER ACCOUNT (Collateral Engine)
# ------------------------------
class UserAccount(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    total_collateral = models.DecimalField(max_digits=30, decimal_places=8, default=0)
    locked_collateral = models.DecimalField(max_digits=30, decimal_places=8, default=0)
    total_pnl = models.DecimalField(max_digits=30, decimal_places=8, default=0)

    def __str__(self):
        return f"{self.user.username} Account"


# ------------------------------
# POSITION MODEL (Core Trading State)
# ------------------------------
class Position(models.Model):
    # Side choices
    LONG = "LONG"
    SHORT = "SHORT"
    SIDE_CHOICES = [(LONG, "Long"), (SHORT, "Short")]

    # State machine
    STATE_OPENING = "OPENING"
    STATE_OPEN = "OPEN"
    STATE_MODIFYING = "MODIFYING"
    STATE_CLOSING = "CLOSING"
    STATE_CLOSED = "CLOSED"
    STATE_LIQUIDATING = "LIQUIDATING"

    STATE_CHOICES = [
        (STATE_OPENING, "Opening"),
        (STATE_OPEN, "Open"),
        (STATE_MODIFYING, "Modifying"),
        (STATE_CLOSING, "Closing"),
        (STATE_CLOSED, "Closed"),
        (STATE_LIQUIDATING, "Liquidating"),
    ]

    # 🔸 owner is OPTIONAL so old data / backend UI still works
    owner = models.ForeignKey(
        UserAccount,
        on_delete=models.CASCADE,
        related_name="positions",
        null=True,
        blank=True,
    )

    symbol = models.CharField(max_length=32, default="BTCUSDT")
    side = models.CharField(max_length=6, choices=SIDE_CHOICES)

    size = models.DecimalField(max_digits=30, decimal_places=8)
    entry_price = models.DecimalField(max_digits=30, decimal_places=8)
    leverage = models.PositiveIntegerField()

    # Margin
    margin = models.DecimalField(max_digits=30, decimal_places=8)
    maintenance_margin_ratio = models.DecimalField(
        max_digits=10, decimal_places=6, default=0.004
    )

    # When equity <= margin * liquidation_threshold_pct ⇒ liquidate
    liquidation_threshold_pct = models.DecimalField(
        max_digits=5, decimal_places=2, default=0.80
    )

    # PnL numbers
    unrealized_pnl = models.DecimalField(max_digits=30, decimal_places=8, default=0)
    realized_pnl = models.DecimalField(max_digits=30, decimal_places=8, default=0)
    funding_accrued = models.DecimalField(max_digits=30, decimal_places=8, default=0)

    liquidation_price = models.DecimalField(
        max_digits=30, decimal_places=8, null=True, blank=True
    )

    state = models.CharField(
        max_length=16, choices=STATE_CHOICES, default=STATE_OPEN
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    # Track last mark price used for PnL / close
    last_mark_price = models.DecimalField(max_digits=30, decimal_places=8, default=0)

    def __str__(self):
        return f"Pos({self.id}) {self.symbol} {self.side} x{self.leverage}"


# ------------------------------
# POSITION EVENT LOG (Audit Trail)
# ------------------------------
class PositionEvent(models.Model):
    EVENT_OPEN = "OPEN"
    EVENT_MODIFY = "MODIFY"
    EVENT_CLOSE = "CLOSE"
    EVENT_LIQUIDATE = "LIQUIDATE"
    EVENT_MARGIN_CALL = "MARGIN_CALL"
    EVENT_FUNDING = "FUNDING"


    EVENT_TYPES = [
        (EVENT_OPEN, "Open"),
        (EVENT_MODIFY, "Modify"),
        (EVENT_CLOSE, "Close"),
        (EVENT_LIQUIDATE, "Liquidate"),
        (EVENT_MARGIN_CALL, "Margin Call"),
        (EVENT_FUNDING, "FUNDING"),
    ]

    position = models.ForeignKey(
        Position, on_delete=models.CASCADE, related_name="events"
    )
    event_type = models.CharField(max_length=20, choices=EVENT_TYPES)
    created_at = models.DateTimeField(auto_now_add=True)

    size = models.DecimalField(max_digits=30, decimal_places=8)
    entry_price = models.DecimalField(max_digits=30, decimal_places=8)
    mark_price = models.DecimalField(max_digits=30, decimal_places=8, default=0)
    margin = models.DecimalField(max_digits=30, decimal_places=8, default=0)
    unrealized_pnl = models.DecimalField(max_digits=30, decimal_places=8, default=0)
    realized_pnl = models.DecimalField(max_digits=30, decimal_places=8, default=0)

    def __str__(self):
        return f"{self.event_type} @ Pos {self.position_id}"


# ------------------------------
# OPTIONAL: PnL HISTORY PER POSITION
# ------------------------------
class PnLSnapshot(models.Model):
    position = models.ForeignKey(
        Position, on_delete=models.CASCADE, related_name="pnl_snapshots"
    )
    timestamp = models.DateTimeField(auto_now_add=True)
    mark_price = models.DecimalField(max_digits=30, decimal_places=8)
    unrealized_pnl = models.DecimalField(max_digits=30, decimal_places=8)

    def __str__(self):
        return f"Snapshot {self.position_id} at {self.timestamp}"
