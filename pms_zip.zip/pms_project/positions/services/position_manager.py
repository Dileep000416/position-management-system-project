# positions/services/position_manager.py

from decimal import Decimal
from django.db import transaction
from ..models import UserAccount, Position, PositionEvent
from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync


import json   # NEW


# ---------- WS BROADCAST HELPER (NEW) ----------
def _broadcast_positions():
    """
    Sends all positions to WebSocket group 'positions'.
    Called after open/close/update events.
    """
    layer = get_channel_layer()
    if not layer:
        return

    from ..serializers import PositionSerializer

    data = PositionSerializer(Position.objects.all(), many=True).data

    async_to_sync(layer.group_send)(
        "positions",              # GROUP NAME
        {
            "type": "positions.update",
            "data": data,
        }
    )


# ---------- Safe Decimal Helper ----------
def _D(x) -> Decimal:
    return x if isinstance(x, Decimal) else Decimal(str(x))


# ---------- Margin Calculation ----------
def calculate_margin(size: Decimal, entry_price: Decimal, leverage: int) -> Decimal:
    size = _D(size)
    entry_price = _D(entry_price)
    leverage = _D(leverage)
    return (size * entry_price) / leverage


# ---------- Unrealized PnL ----------
def calculate_unrealized(position: Position, mark_price: Decimal) -> Decimal:
    mark_price = _D(mark_price)

    if position.side == Position.LONG:
        return (mark_price - position.entry_price) * position.size
    else:
        return (position.entry_price - mark_price) * position.size


# ---------- Liquidation Calculation ----------
def calculate_liquidation_price(position: Position) -> Decimal:
    E = _D(position.entry_price)
    L = _D(position.leverage)
    mmr = _D(position.maintenance_margin_ratio)
    one = Decimal("1")

    if position.side == Position.LONG:
        return E * (one - one / L + mmr)
    else:
        return E * (one + one / L - mmr)


# ---------- LEVERAGE TIERS ----------
def get_leverage_mmr(leverage: int) -> Decimal:
    if leverage <= 5:
        return Decimal("0.01")
    elif leverage <= 10:
        return Decimal("0.02")
    elif leverage <= 25:
        return Decimal("0.05")
    elif leverage <= 50:
        return Decimal("0.10")
    else:
        raise ValueError("Leverage above 50x is not allowed.")


# ---------- OPEN POSITION ----------
@transaction.atomic
def open_position(account: UserAccount, symbol: str, side: str, size: Decimal,
                  leverage: int, entry_price: Decimal) -> Position:

    if leverage < 1 or leverage > 50:
        raise ValueError("Leverage must be between 1x and 50x.")

    size = _D(size)
    entry_price = _D(entry_price)

    if size <= 0:
        raise ValueError("Position size must be greater than zero.")
    if entry_price <= 0:
        raise ValueError("Entry price must be greater than zero.")

    margin = calculate_margin(size, entry_price, leverage)

    free = account.total_collateral - account.locked_collateral
    if free < margin:
        raise ValueError("Insufficient collateral to open position")

    mmr = get_leverage_mmr(leverage)

    pos = Position.objects.create(
        owner=account,
        symbol=symbol,
        side=side,
        size=size,
        entry_price=entry_price,
        leverage=leverage,
        margin=margin,
        maintenance_margin_ratio=mmr,
        state=Position.STATE_OPEN,
        last_mark_price=entry_price,
    )

    pos.liquidation_price = calculate_liquidation_price(pos)
    pos.save()

    account.locked_collateral += margin
    account.save()

    PositionEvent.objects.create(
        position=pos,
        event_type=PositionEvent.EVENT_OPEN,
        size=size,
        entry_price=entry_price,
        margin=margin,
        mark_price=entry_price,
        unrealized_pnl=0,
        realized_pnl=0,
    )

    _broadcast_positions()  # 🔥 NEW

    return pos


# ---------- UPDATE ----------
@transaction.atomic
def update_unrealized(position: Position, mark_price: Decimal) -> Position:
    mark_price = _D(mark_price)

    position.last_mark_price = mark_price
    position.unrealized_pnl = calculate_unrealized(position, mark_price)
    position.save()

    PositionEvent.objects.create(
        position=position,
        event_type=PositionEvent.EVENT_MODIFY,
        size=position.size,
        entry_price=position.entry_price,
        mark_price=mark_price,
        margin=position.margin,
        unrealized_pnl=position.unrealized_pnl,
        realized_pnl=position.realized_pnl,
    )

    _maybe_liquidate(position)

    _broadcast_positions()  # 🔥 NEW

    return position


# ---------- CLOSE ----------
@transaction.atomic
def close_position(position: Position, mark_price: Decimal, reason="CLOSE") -> Position:
    mark_price = _D(mark_price)

    final_pnl = calculate_unrealized(position, mark_price)

    acc = position.owner
    acc.locked_collateral -= position.margin
    acc.total_collateral += final_pnl
    acc.total_pnl += final_pnl
    acc.save()

    position.realized_pnl += final_pnl
    position.unrealized_pnl = Decimal("0")
    position.last_mark_price = mark_price
    position.state = Position.STATE_CLOSED
    position.save()

    PositionEvent.objects.create(
        position=position,
        event_type=PositionEvent.EVENT_LIQUIDATE if reason == "LIQUIDATE" else PositionEvent.EVENT_CLOSE,
        size=position.size,
        entry_price=position.entry_price,
        mark_price=mark_price,
        margin=position.margin,
        unrealized_pnl=0,
        realized_pnl=position.realized_pnl,
    )

    _broadcast_positions()  # 🔥 NEW

    return position


# ---------- LIQUIDATION CHECK ----------
def _maybe_liquidate(position: Position):
    equity = _D(position.margin) + _D(position.unrealized_pnl)
    min_equity = _D(position.margin) * _D(position.maintenance_margin_ratio)

    if equity <= min_equity and position.state == Position.STATE_OPEN:
        position.state = Position.STATE_LIQUIDATING
        position.save()
        close_position(position, position.last_mark_price, reason="LIQUIDATE")


# ---------- FUNDING ----------
FUNDING_RATE = Decimal("0.0001")

@transaction.atomic
def apply_funding(position: Position):

    if position.state != Position.STATE_OPEN:
        return position

    fee = position.size * position.last_mark_price * FUNDING_RATE

    account = position.owner

    if position.side == Position.LONG:
        account.total_collateral -= fee
        position.realized_pnl -= fee
    else:
        account.total_collateral += fee
        position.realized_pnl += fee

    account.save()
    position.save()

    PositionEvent.objects.create(
        position=position,
        event_type=PositionEvent.EVENT_FUNDING,
        size=position.size,
        entry_price=position.entry_price,
        mark_price=position.last_mark_price,
        margin=position.margin,
        unrealized_pnl=position.unrealized_pnl,
        realized_pnl=position.realized_pnl,
    )

    _broadcast_positions()  # 🔥 NEW

    return position
