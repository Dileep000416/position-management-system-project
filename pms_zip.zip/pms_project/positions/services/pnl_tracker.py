from decimal import Decimal

def calculate_unrealized_pnl(is_long: bool, size: Decimal, mark_price: Decimal, entry_price: Decimal) -> Decimal:
    if is_long:
        return size * (mark_price - entry_price)
    else:
        return size * (entry_price - mark_price)
