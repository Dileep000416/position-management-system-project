from decimal import Decimal, getcontext
getcontext().prec = 28

def initial_margin(position_value: Decimal, leverage: int) -> Decimal:
    return position_value / Decimal(leverage)

def calculate_liq_price_long(entry_price: Decimal, leverage: Decimal, mmr: Decimal) -> Decimal:
    return entry_price * (Decimal(1) - (Decimal(1)/leverage) + mmr)

def calculate_liq_price_short(entry_price: Decimal, leverage: Decimal, mmr: Decimal) -> Decimal:
    return entry_price * (Decimal(1) + (Decimal(1)/leverage) - mmr)
