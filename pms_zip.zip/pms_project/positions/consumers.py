# positions/consumers.py

import json
from channels.generic.websocket import AsyncWebsocketConsumer
from .models import Position
from .serializers import PositionSerializer

class PositionsConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        await self.channel_layer.group_add("positions", self.channel_name)
        await self.accept()
        print("WS Connected:", self.channel_name)

        # send initial state
        await self.send_positions()

    async def disconnect(self, close_code):
        await self.channel_layer.group_discard("positions", self.channel_name)
        print("WS Disconnected:", self.channel_name)

    async def send_positions(self):
        """
        Sends the current positions list to all clients
        """
        positions = Position.objects.all().order_by("-created_at")
        payload = {
            "type": "positions.update",
            "data": PositionSerializer(positions, many=True).data
        }
        await self.channel_layer.group_send(
            "positions",
            {"type": "positions_broadcast", "payload": payload}
        )

    async def positions_broadcast(self, event):
        await self.send(text_data=json.dumps(event["payload"]))
