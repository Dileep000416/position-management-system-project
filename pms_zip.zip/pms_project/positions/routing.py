from django.urls import re_path
from .consumers import PositionsConsumer

websocket_urlpatterns = [
    re_path(r'ws/positions/$', PositionsConsumer.as_asgi()),
]
