from django.urls import path
from .views import (
    OpenPositionView,
    MarkPriceView,
    ClosePositionView,
    PositionListView,
    PositionEventHistory,
)
from .views import FundingApplyView

urlpatterns = [
    # GET → List positions of logged-in user
    path("", PositionListView.as_view(), name="positions-list"),

    # POST → Open a new position
    path("open/", OpenPositionView.as_view(), name="open-position"),

    # POST → Update PnL by mark price
    path("<int:pk>/mark/", MarkPriceView.as_view(), name="mark-price"),

    # POST → Close a position
    path("<int:pk>/close/", ClosePositionView.as_view(), name="close-position"),

    # GET → Complete event history (audit log)
    path("<int:pk>/events/", PositionEventHistory.as_view(), name="position-events"),

    path("funding/apply/", FundingApplyView.as_view()), 

    
]
