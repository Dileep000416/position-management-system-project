from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.generics import ListAPIView
from django.shortcuts import get_object_or_404
from decimal import Decimal

from .models import Position, UserAccount, PositionEvent
from .serializers import PositionSerializer, PositionEventSerializer

from positions.services.position_manager import (
    open_position,
    update_unrealized,
    close_position,
    apply_funding,      # 👈 NEW IMPORT FOR FUNDING
)

# --------------------------------------------------------------------
# OPEN POSITION (POST) - VALIDATION ADDED
# --------------------------------------------------------------------
class OpenPositionView(APIView):
    def post(self, request):
        data = request.data

        # -------- VALIDATION LAYER --------
        required = ["symbol", "side", "size", "leverage", "entry_price"]
        for field in required:
            if field not in data or str(data[field]).strip() == "":
                return Response({"error": f"{field} is required"}, status=400)

        if data["symbol"] not in ["BTCUSDT", "ETHUSDT"]:
            return Response({"error": "Invalid symbol"}, status=400)

        if data["side"] not in ["LONG", "SHORT"]:
            return Response({"error": "Side must be LONG or SHORT"}, status=400)

        try:
            size = Decimal(data["size"])
            if size <= 0:
                return Response({"error": "Size must be greater than 0"}, status=400)
        except:
            return Response({"error": "Invalid size value"}, status=400)

        try:
            entry = Decimal(data["entry_price"])
            if entry <= 0:
                return Response({"error": "Entry price must be greater than 0"}, status=400)
        except:
            return Response({"error": "Invalid entry price value"}, status=400)

        try:
            lev = int(data["leverage"])
            if lev < 1 or lev > 100:
                return Response({"error": "Leverage must be between 1 and 100"}, status=400)
        except:
            return Response({"error": "Invalid leverage value"}, status=400)

        # Always use demo account with ID=1
        account, _ = UserAccount.objects.get_or_create(id=1)

        # CREATE POSITION
        pos = open_position(
            account,
            data["symbol"],
            data["side"],
            size,
            lev,
            entry
        )

        # Log OPEN event
        PositionEvent.objects.create(
            position=pos,
            event_type=PositionEvent.EVENT_OPEN,
            size=pos.size,
            entry_price=pos.entry_price,
            mark_price=pos.last_mark_price,
            unrealized_pnl=pos.unrealized_pnl,
            realized_pnl=pos.realized_pnl,
            margin=pos.margin,
        )

        return Response(PositionSerializer(pos).data, status=201)


# --------------------------------------------------------------------
# UPDATE MARK PRICE (LIVE FEED)
# --------------------------------------------------------------------
class MarkPriceView(APIView):
    def post(self, request, pk):
        pos = get_object_or_404(Position, pk=pk)
        mark = Decimal(request.data["mark_price"])
        pos = update_unrealized(pos, mark)
        return Response(PositionSerializer(pos).data)


# --------------------------------------------------------------------
# CLOSE POSITION
# --------------------------------------------------------------------
class ClosePositionView(APIView):
    def post(self, request, pk):
        pos = get_object_or_404(Position, pk=pk)
        mark = Decimal(request.data["mark_price"])
        pos = close_position(pos, mark)

        PositionEvent.objects.create(
            position=pos,
            event_type=PositionEvent.EVENT_CLOSE,
            size=pos.size,
            entry_price=pos.entry_price,
            mark_price=mark,
            unrealized_pnl=pos.unrealized_pnl,
            realized_pnl=pos.realized_pnl,
            margin=pos.margin,
        )

        return Response(PositionSerializer(pos).data)


# --------------------------------------------------------------------
# PUBLIC POSITION LIST
# --------------------------------------------------------------------
class PositionListView(ListAPIView):
    serializer_class = PositionSerializer

    def get_queryset(self):
        return Position.objects.all().order_by("-created_at")


# --------------------------------------------------------------------
# EVENT HISTORY
# --------------------------------------------------------------------
class PositionEventHistory(APIView):
    def get(self, request, pk):
        pos = get_object_or_404(Position, pk=pk)
        events = pos.events.all().order_by("-created_at")
        return Response(PositionEventSerializer(events, many=True).data)


# --------------------------------------------------------------------
# STEP-8 FUNDING APPLY ENDPOINT
# --------------------------------------------------------------------
class FundingApplyView(APIView):
    """
    Applies funding fees to ALL open positions.
    Longs pay fee, shorts receive fee.
    """
    def post(self, request):
        open_positions = Position.objects.filter(state=Position.STATE_OPEN)
        for pos in open_positions:
            apply_funding(pos)

        return Response(
            {"status": "funding applied", "count": open_positions.count()},
            status=200
        )
