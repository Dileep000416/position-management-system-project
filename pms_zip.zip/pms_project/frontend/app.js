const API = "http://127.0.0.1:8000/api/positions/";
let positions = [];
let latestPrice = 0;
let activeFilter = "ALL";  // ⭐ FILTER STATE

/* ===== TOKEN HEADER FOR AUTH ===== */
function getAuthHeaders() {
    return {
        "Authorization": "Bearer " + localStorage.getItem("access"),
        "Content-Type": "application/json"
    };
}

/* ===== 1) LOAD POSITIONS ===== */
async function loadPositions() {
    try {
        const res = await fetch(API, { headers: getAuthHeaders() });

        if (res.status === 401) {
            alert("Session expired. Please login again.");
            window.location.href = "login.html";
            return;
        }

        positions = await res.json();
        console.log("Positions loaded:", positions);

        // ⭐ Render filtered view and analytics only if available
        applyFilter(activeFilter);
        if (document.getElementById("analyticsBox")) updateAnalytics();

    } catch (err) {
        console.error("Error loading positions", err);
    }
}

/* ===== 2) LIVE BTC PRICE ===== */
async function fetchPrice() {
    try {
        const res = await fetch("https://api.binance.com/api/v3/ticker/price?symbol=BTCUSDT");
        const data = await res.json();
        latestPrice = parseFloat(data.price);

        const el = document.getElementById("btcPrice");
        if (el) el.textContent = `$${latestPrice.toLocaleString()}`;

        updatePnL();
    } catch (e) {
        console.log("BTC price error:", e);
    }
}

/* ===== 3) UPDATE PNL LIVE ===== */
function updatePnL() {
    const rows = document.querySelectorAll("#positions-table tbody tr");

    rows.forEach((row) => {
        const pos = positions.find(p => p.id == row.dataset.id);
        if (!pos) return;

        const entry = parseFloat(pos.entry_price);
        const size = parseFloat(pos.size);
        const side = pos.side;

        let pnl = side === "LONG"
            ? (latestPrice - entry) * size
            : (entry - latestPrice) * size;

        const cell = row.children[5];
        if (!cell) return;

        cell.textContent = pnl.toFixed(2);
        cell.className = pnl > 0 ? "profit" : pnl < 0 ? "loss" : "";
    });
}

/* ===== 4) CLOSE POSITION (BACKEND) ===== */
async function closeBackendPosition(id) {
    if (!confirm("Close this position?")) return;

    await fetch(`${API}${id}/close/`, {
        method: "POST",
        headers: getAuthHeaders()
    });

    loadPositions();
}

/* ===== 5) TRADINGVIEW CHART ===== */
function initTradingViewChart() {
    if (typeof TradingView === "undefined") {
        return setTimeout(initTradingViewChart, 1000);
    }

    new TradingView.widget({
        container_id: "tv_chart_container",
        symbol: "BINANCE:BTCUSDT",
        interval: "15",
        theme: "dark",
        autosize: true,
        style: "1",
        locale: "en"
    });
}

/* ===== 6) EXPORT POSITIONS TO CSV ===== */
function exportToCSV() {
    if (!positions.length) {
        alert("No positions available to export!");
        return;
    }

    const headers = ["ID", "Symbol", "Side", "Size", "Entry Price", "State"];
    const rows = positions.map(p =>
        [p.id, p.symbol, p.side, p.size, p.entry_price, p.state]
    );

    let csv = headers.join(",") + "\n" +
              rows.map(r => r.join(",")).join("\n");

    const blob = new Blob([csv], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);

    const a = document.createElement("a");
    a.href = url;
    a.download = `positions_${new Date().toISOString().slice(0,10)}.csv`;
    a.click();
}

/* ===== SAFE BUTTON ATTACH ===== */
const exportBtn = document.getElementById("exportCsvBtn");
if (exportBtn) exportBtn.addEventListener("click", exportToCSV);

/* ===== 7) FILTER POSITIONS ===== */
function applyFilter(type) {
    activeFilter = type;

    const filtered = positions.filter(pos => {
        if (type === "ALL") return true;
        if (type === "OPEN") return pos.state === "OPEN";
        if (type === "CLOSED") return pos.state === "CLOSED";
        if (type === "LONG") return pos.side === "LONG";
        if (type === "SHORT") return pos.side === "SHORT";
        return true;
    });

    const tbody = document.querySelector("#positions-table tbody");
    if (!tbody) return; // ⭐ backend safety
    tbody.innerHTML = "";

    filtered.forEach(pos => {
        tbody.innerHTML += `
            <tr data-id="${pos.id}">
                <td>${pos.id}</td>
                <td>${pos.symbol}</td>
                <td>${pos.side}</td>
                <td>${pos.size}</td>
                <td>${pos.entry_price}</td>
                <td class="pnl">Live...</td>
                <td>${pos.state}</td>
                <td>${
                    pos.state === "OPEN"
                    ? `<button class="close-btn" onclick="closeBackendPosition(${pos.id})">Close</button>`
                    : "-"
                }</td>
            </tr>
        `;
    });

    updatePnL();
}

/* ===== ANALYTICS ENGINE ===== */
function updateAnalytics() {
    if (!document.getElementById("analyticsBox")) return; // ⭐ prevent backend crash

    const total = positions.length;
    const open = positions.filter(p => p.state === "OPEN").length;
    const closed = positions.filter(p => p.state === "CLOSED").length;

    const wins = positions.filter(p => p.unrealized_pnl > 0 && p.state === "CLOSED").length;
    const winRate = closed ? ((wins / closed) * 100).toFixed(1) : 0;

    const avg = total
        ? (positions.reduce((sum, p) => sum + (p.unrealized_pnl || 0), 0) / total).toFixed(2)
        : 0;

    document.getElementById("totalPos").textContent = total;
    document.getElementById("openPos").textContent = open;
    document.getElementById("closedPos").textContent = closed;
    document.getElementById("winRate").textContent = winRate + "%";
    document.getElementById("avgPnl").textContent = avg;
}

/* ===== THEME TOGGLE ===== */
document.addEventListener("DOMContentLoaded", () => {
    const toggleBtn = document.getElementById("themeToggle");
    if (!toggleBtn) return; // ⭐ prevent backend crash

    let theme = localStorage.getItem("theme") || "dark";
    applyTheme(theme);

    toggleBtn.addEventListener("click", () => {
        theme = theme === "dark" ? "light" : "dark";
        localStorage.setItem("theme", theme);
        applyTheme(theme);
    });
});

function applyTheme(mode) {
    if (!document.getElementById("themeToggle")) return; // ⭐ no toggle on backend

    document.body.className = mode === "dark" ? "dark-theme" : "light-theme";
    document.getElementById("themeToggle").textContent =
        mode === "dark" ? "🌙 Dark" : "☀️ Light";
}

/* ===== INIT ===== */
if (!localStorage.getItem("access")) {
    window.location.href = "login.html";
}

loadPositions();
fetchPrice();
initTradingViewChart();

setInterval(fetchPrice, 2000);
setInterval(loadPositions, 7000);
