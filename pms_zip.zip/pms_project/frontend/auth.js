const TOKEN_URL = "http://127.0.0.1:8000/api/token/";

document.getElementById("loginForm").addEventListener("submit", async (e) => {
    e.preventDefault();

    const payload = {
        username: document.getElementById("username").value.trim(),
        password: document.getElementById("password").value.trim(),
    };

    try {
        const res = await fetch(TOKEN_URL, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
        });

        const data = await res.json();
        console.log("🔐 Auth response:", data);

        if (!res.ok || !data.access) {
            document.getElementById("loginError").style.display = "block";
            return;
        }

        // 🔐 Store tokens and username
        localStorage.setItem("access", data.access);
        localStorage.setItem("refresh", data.refresh);
        localStorage.setItem("username", payload.username);

        alert("Login Successful!");
        window.location.href = "index.html";
    } catch (err) {
        console.log("Login Error:", err);
        document.getElementById("loginError").style.display = "block";
    }
});
