console.log("📡 Connecting to WebSocket...");

const ws = new WebSocket("ws://127.0.0.1:8000/ws/positions/");

ws.onmessage = (event) => {
  const payload = JSON.parse(event.data);

  if (payload.type === "positions.update") {
      console.log("🔥 LIVE UPDATE RECEIVED", payload.data);

      positions = payload.data; // replace global positions list
      renderTable();
      updateAnalytics();
  }
};

ws.onopen = () => console.log("🟢 WebSocket Connected");
ws.onclose = () => console.log("🔴 WebSocket Disconnected");
